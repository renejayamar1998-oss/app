# Zayne Video Editing (Android, offline)
Kotlin + Jetpack Compose + Media3 Transformer + Vosk (offline captions).

## Paano makuha ang APK (phone lang)
1. Gumawa ng bagong GitHub repo, i-upload ang laman ng folder na ito (kasama ang `.github`).
2. Actions tab -> "Build APK" -> hintayin matapos (~5-8 min).
3. I-download ang artifact `ZayneVideoEditing-apk`, i-unzip, i-install ang .apk.

## Auto-caption
Mag-download ng Vosk model (https://alphacephei.com/vosk/models) — hanapin ang Tagalog/Filipino
o `vosk-model-small-en-us`. Ilagay ang .zip sa phone, tapos "Pumili ng Vosk model" sa app.
