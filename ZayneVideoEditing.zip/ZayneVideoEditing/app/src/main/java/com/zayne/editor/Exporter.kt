package com.zayne.editor

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.net.Uri
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import androidx.media3.common.*
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.*
import androidx.media3.transformer.*
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.*
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class ClipSpec(val uri: Uri, val durMs: Long, val startMs: Long, val endMs: Long)
data class Opts(val autoCut: Boolean, val captions: Boolean, val sfx: Boolean, val speed: Float,
                val logo: Uri?, val music: Uri?, val model: File?)
private class Seg(val ci: Int, val uri: Uri, val s: Long, val e: Long, val zoom: Boolean)

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
suspend fun exportVideo(ctx: Context, clips: List<ClipSpec>, o: Opts, status: (String) -> Unit): File {
    val segs = ArrayList<Seg>(); val cuesBy = HashMap<Int, List<Cue>>()

    withContext(Dispatchers.Default) {
        clips.forEachIndexed { ci, c ->
            status("Ina-analyze ang clip ${ci + 1}/${clips.size}…")
            val pcm = if (o.autoCut || o.captions || o.sfx) decodePcm16k(ctx, c.uri) else null
            val ranges = if (o.autoCut && pcm != null)
                silenceRanges(pcm).mapNotNull { val s = maxOf(it.first, c.startMs); val e = minOf(it.second, c.endMs); if (e - s > 200) s to e else null }
            else listOf(c.startMs to c.endMs)
            val peaks = if (o.sfx && pcm != null) loudPeaks(pcm) else emptyList()
            if (o.captions && pcm != null && o.model != null) { status("Auto-caption (clip ${ci + 1})…"); cuesBy[ci] = transcribe(o.model, pcm) }
            for ((rs, re) in ranges) {
                var cur = rs
                for (p in peaks.filter { it > rs + 400 && it < re - 600 }) {
                    val a = p - 150; if (a <= cur) continue
                    segs += Seg(ci, c.uri, cur, a, false); segs += Seg(ci, c.uri, a, a + 500, true); cur = a + 500
                }
                segs += Seg(ci, c.uri, cur, re, false)
            }
        }
    }
    segs.removeAll { it.e - it.s < 100 }
    require(segs.isNotEmpty()) { "Walang natirang video (baka lahat ay silence)." }

    // output timeline: caption times + SFX times
    var t = 0L; val sfxT = ArrayList<Long>(); val outCues = ArrayList<Cue>()
    for (sg in segs) {
        if (sg.zoom) sfxT += t
        cuesBy[sg.ci]?.forEach { c ->
            if (c.startMs >= sg.s && c.startMs < sg.e) {
                val st = t + ((c.startMs - sg.s) / o.speed).toLong()
                outCues += Cue(st, st + minOf(((c.endMs - c.startMs) / o.speed).toLong(), 3000), c.text)
            }
        }
        t += ((sg.e - sg.s) / o.speed).toLong()
    }

    status("Ine-export…")
    val out = File(ctx.cacheDir, "zayne_${System.currentTimeMillis()}.mp4")
    return withContext(Dispatchers.Main) {
        var zoomToggle = false
        val items = segs.map { sg ->
            val mi = MediaItem.Builder().setUri(sg.uri).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setStartPositionMs(sg.s).setEndPositionMs(sg.e).build()).build()
            val v = ArrayList<Effect>()
            if (o.speed != 1f) v += SpeedChangeEffect(o.speed)
            if (sg.zoom) { // "animation": punch-in zoom + bahagyang ikot, salitan
                zoomToggle = !zoomToggle
                v += ScaleAndRotateTransformation.Builder().setScale(if (zoomToggle) 1.2f else 1.35f, if (zoomToggle) 1.2f else 1.35f)
                    .setRotationDegrees(if (zoomToggle) 0f else 3f).build()
            }
            val a = if (o.speed != 1f) listOf<AudioProcessor>(SonicAudioProcessor().apply { setSpeed(o.speed) }) else emptyList()
            EditedMediaItem.Builder(mi).setEffects(Effects(a, v)).build()
        }
        val sequences = ArrayList<EditedMediaItemSequence>()
        sequences += EditedMediaItemSequence.Builder(*items.toTypedArray()).build()

        if (o.sfx && sfxT.isNotEmpty()) {
            val sfxItem = EditedMediaItem.Builder(MediaItem.fromUri("android.resource://${ctx.packageName}/raw/sfx_whoosh")).build()
            val b = EditedMediaItemSequence.Builder(); var cursor = 0L
            for (x in sfxT) { if (x > cursor) b.addGap((x - cursor) * 1000); b.addItem(sfxItem); cursor = maxOf(x, cursor) + 600 }
            sequences += b.build()
        }
        o.music?.let {
            val m = EditedMediaItem.Builder(MediaItem.fromUri(it)).setRemoveVideo(true).build()
            sequences += EditedMediaItemSequence.Builder(m).setIsLooping(true).build()
        }

        val overlays = ArrayList<TextureOverlay>()
        o.logo?.let { u ->
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }?.let { bmp ->
                val bw = 220; val scaled = Bitmap.createScaledBitmap(bmp, bw, (bmp.height * bw / bmp.width.toFloat()).toInt(), true)
                overlays += BitmapOverlay.createStaticBitmapOverlay(scaled,
                    OverlaySettings.Builder().setBackgroundFrameAnchor(0.82f, 0.88f).build())
            }
        }
        if (outCues.isNotEmpty()) overlays += object : TextOverlay() {
            override fun getText(presentationTimeUs: Long): SpannableString {
                val ms = presentationTimeUs / 1000
                val text = outCues.firstOrNull { ms >= it.startMs && ms < it.endMs }?.text ?: " "
                return SpannableString(text).apply {
                    setSpan(ForegroundColorSpan(Color.WHITE), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    setSpan(AbsoluteSizeSpan(56), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            override fun getOverlaySettings(presentationTimeUs: Long) =
                OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.65f).build()
        }
        val vEffects = ArrayList<Effect>()
        vEffects += Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT)
        if (overlays.isNotEmpty()) vEffects += OverlayEffect(ImmutableList.copyOf(overlays))

        val composition = Composition.Builder(sequences).setEffects(Effects(emptyList(), vEffects)).build()
        suspendCancellableCoroutine { cont ->
            val tr = Transformer.Builder(ctx).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(c: Composition, r: ExportResult) { cont.resume(out) }
                    override fun onError(c: Composition, r: ExportResult, e: ExportException) { cont.resumeWithException(e) }
                }).build()
            tr.start(composition, out.absolutePath)
            cont.invokeOnCancellation { tr.cancel() }
        }
    }
}

fun saveToMovies(ctx: Context, f: File) {
    val cv = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZayneVideo")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
    ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
}
