package com.zayne.editor

import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s); setContent { MaterialTheme { App() } } }
}

fun modelDir(ctx: android.content.Context): File? {
    val d = File(ctx.filesDir, "vosk")
    if (File(d, "am").exists()) return d
    return d.listFiles()?.firstOrNull { it.isDirectory && File(it, "am").exists() }
}

fun unzipModel(ctx: android.content.Context, uri: Uri) {
    val dir = File(ctx.filesDir, "vosk"); dir.deleteRecursively(); dir.mkdirs()
    ZipInputStream(ctx.contentResolver.openInputStream(uri)).use { z ->
        var e = z.nextEntry
        while (e != null) {
            val f = File(dir, e.name)
            if (!f.canonicalPath.startsWith(dir.canonicalPath)) throw SecurityException("bad zip")
            if (e.isDirectory) f.mkdirs() else { f.parentFile!!.mkdirs(); f.outputStream().use { z.copyTo(it) } }
            e = z.nextEntry
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val clips = remember { mutableStateListOf<ClipSpec>() }
    var autoCut by remember { mutableStateOf(true) }
    var captions by remember { mutableStateOf(false) }
    var sfx by remember { mutableStateOf(true) }
    var speed by remember { mutableFloatStateOf(1f) }
    var logo by remember { mutableStateOf<Uri?>(null) }
    var music by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var hasModel by remember { mutableStateOf(modelDir(ctx) != null) }

    val pickVideos = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { us ->
        us.forEach { u ->
            val r = MediaMetadataRetriever().apply { setDataSource(ctx, u) }
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L; r.release()
            clips += ClipSpec(u, d, 0, d)
        }
    }
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { logo = it }
    val pickMusic = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { music = it }
    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) scope.launch {
            status = "Ina-unzip ang model…"
            try { withContext(Dispatchers.IO) { unzipModel(ctx, u) }; hasModel = modelDir(ctx) != null; status = if (hasModel) "Handa na ang model." else "Mukhang hindi Vosk model ang zip." }
            catch (e: Throwable) { status = "Error: ${e.message}" }
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Zayne Video Editing", style = MaterialTheme.typography.headlineSmall) }
        item { Button(onClick = { pickVideos.launch("video/*") }) { Text("+ Magdagdag ng video clips (sunod-sunod)") } }
        itemsIndexed(clips) { i, c ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                Text("Clip ${i + 1}: ${c.startMs / 1000f}s – ${c.endMs / 1000f}s  (trim)")
                RangeSlider(value = c.startMs / 1000f..c.endMs / 1000f, valueRange = 0f..(c.durMs / 1000f),
                    onValueChange = { clips[i] = c.copy(startMs = (it.start * 1000).toLong(), endMs = (it.endInclusive * 1000).toLong()) })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { val m = (c.startMs + c.endMs) / 2
                        clips[i] = c.copy(endMs = m); clips.add(i + 1, c.copy(startMs = m)) }) { Text("Split (gitna)") }
                    TextButton(onClick = { clips.removeAt(i) }) { Text("Delete") }
                    if (i > 0) TextButton(onClick = { val x = clips.removeAt(i); clips.add(i - 1, x) }) { Text("↑") }
                }
            } }
        }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Switch(autoCut, { autoCut = it }); Spacer(Modifier.width(8.dp)); Text("Auto-cut ng silence (dudugtong-dugtungin ang mga putol)") } }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Switch(sfx, { sfx = it }); Spacer(Modifier.width(8.dp)); Text("SFX + zoom transition sa pinakamalakas na tunog") } }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Switch(captions, { captions = it }); Spacer(Modifier.width(8.dp)); Text("Auto-caption (offline)") } }
        if (captions) item { OutlinedButton(onClick = { pickModel.launch("application/zip") }) { Text(if (hasModel) "Model ✓ (palitan)" else "Pumili ng Vosk model (.zip)") } }
        item { Text("Speed: ${"%.2f".format(speed)}x"); Slider(speed, { speed = it }, valueRange = 0.5f..2f) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pickMusic.launch("audio/*") }) { Text(if (music != null) "Music ✓" else "Music") }
            OutlinedButton(onClick = { pickLogo.launch("image/*") }) { Text(if (logo != null) "Logo ✓" else "Logo") }
        } }
        item { Button(enabled = !busy && clips.isNotEmpty(), onClick = {
            scope.launch {
                busy = true
                try {
                    val md = if (captions) modelDir(ctx) else null
                    if (captions && md == null) throw IllegalStateException("Pumili muna ng Vosk model.")
                    val f = exportVideo(ctx, clips.toList(), Opts(autoCut, captions, sfx, speed, logo, music, md)) { status = it }
                    withContext(Dispatchers.IO) { saveToMovies(ctx, f) }
                    status = "Tapos na! Nasa Movies/ZayneVideo."
                } catch (e: Throwable) { status = "Error: ${e.message}" }
                busy = false
            }
        }) { Text(if (busy) "Ginagawa…" else "EXPORT") } }
        item { Text(status) }
    }
}
