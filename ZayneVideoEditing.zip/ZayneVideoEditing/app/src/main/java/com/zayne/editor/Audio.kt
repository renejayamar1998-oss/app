package com.zayne.editor

import android.content.Context
import android.media.*
import android.net.Uri
import java.nio.ByteOrder

class Pcm(val samples: ShortArray, val rate: Int = 16000)

/** Decode any video/audio file to mono 16 kHz PCM (kailangan ng Vosk at ng analysis). */
fun decodePcm16k(ctx: Context, uri: Uri): Pcm {
    val ex = MediaExtractor().apply { setDataSource(ctx, uri, null) }
    val idx = (0 until ex.trackCount).first {
        ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")
    }
    ex.selectTrack(idx)
    val fmt = ex.getTrackFormat(idx)
    val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
    codec.configure(fmt, null, null, 0); codec.start()
    var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
    var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
    var buf = ShortArray(1 shl 20); var n = 0; var acc = 0.0
    val info = MediaCodec.BufferInfo(); var inDone = false; var outDone = false
    while (!outDone) {
        if (!inDone) {
            val i = codec.dequeueInputBuffer(10_000)
            if (i >= 0) {
                val b = codec.getInputBuffer(i)!!
                val sz = ex.readSampleData(b, 0)
                if (sz < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                else { codec.queueInputBuffer(i, 0, sz, ex.sampleTime, 0); ex.advance() }
            }
        }
        val o = codec.dequeueOutputBuffer(info, 10_000)
        if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            val f = codec.outputFormat
            rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        } else if (o >= 0) {
            val b = codec.getOutputBuffer(o)!!
            b.position(info.offset); b.limit(info.offset + info.size)
            val s = b.order(ByteOrder.nativeOrder()).asShortBuffer()
            val step = rate / 16000.0
            for (f in 0 until s.remaining() / ch) {
                acc += 1.0
                if (acc >= step) {
                    acc -= step
                    var sum = 0; for (c in 0 until ch) sum += s.get(f * ch + c)
                    if (n == buf.size) buf = buf.copyOf(n * 2)
                    buf[n++] = (sum / ch).toShort()
                }
            }
            codec.releaseOutputBuffer(o, false)
            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
        }
    }
    codec.stop(); codec.release(); ex.release()
    return Pcm(buf.copyOf(n))
}

private const val FRAME = 320 // 20 ms @16k

fun envelope(p: Pcm): FloatArray = FloatArray(p.samples.size / FRAME) { f ->
    var s = 0.0
    for (i in f * FRAME until (f + 1) * FRAME) s += p.samples[i].toDouble() * p.samples[i]
    Math.sqrt(s / FRAME).toFloat()
}

/** Mga bahaging may tunog (ms). Tinatanggal ang katahimikan >0.35s. */
fun silenceRanges(p: Pcm): List<Pair<Long, Long>> {
    val env = envelope(p); if (env.isEmpty()) return emptyList()
    val floor = env.sorted()[env.size / 10]
    val thr = maxOf(floor * 3f, 300f)
    val minSilence = 18   // frames (~0.36s)
    val out = ArrayList<Pair<Int, Int>>()
    var start = -1; var quiet = 0
    for (i in env.indices) {
        if (env[i] > thr) { if (start < 0) start = i; quiet = 0 }
        else if (start >= 0 && ++quiet >= minSilence) { out += start to (i - quiet); start = -1; quiet = 0 }
    }
    if (start >= 0) out += start to env.size - 1
    return out.map { (a, b) -> maxOf(0L, a * 20L - 80) to (b * 20L + 80 + 20) }.filter { it.second - it.first > 200 }
}

/** Mga sandali na pinakamalakas ang tunog (ms) — dito ilalagay ang SFX + transition. */
fun loudPeaks(p: Pcm): List<Long> {
    val env = envelope(p); if (env.size < 10) return emptyList()
    val thr = env.sorted()[(env.size * 0.97).toInt().coerceAtMost(env.size - 1)]
    val peaks = ArrayList<Long>(); var last = -10_000L
    for (i in 1 until env.size - 1) {
        val t = i * 20L
        if (env[i] >= thr && env[i] >= env[i - 1] && env[i] >= env[i + 1] && t - last > 2500) { peaks += t; last = t }
    }
    return peaks
}
