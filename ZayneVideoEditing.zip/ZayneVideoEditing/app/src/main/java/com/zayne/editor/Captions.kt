package com.zayne.editor

import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

class Cue(val startMs: Long, val endMs: Long, val text: String)

/** Offline speech-to-text gamit ang Vosk. modelDir = na-unzip na Vosk model (hal. Tagalog). */
fun transcribe(modelDir: File, pcm: Pcm): List<Cue> {
    val words = ArrayList<Triple<Long, Long, String>>()
    fun grab(json: String) {
        JSONObject(json).optJSONArray("result")?.let { a ->
            for (i in 0 until a.length()) {
                val w = a.getJSONObject(i)
                words += Triple((w.getDouble("start") * 1000).toLong(), (w.getDouble("end") * 1000).toLong(), w.getString("word"))
            }
        }
    }
    Model(modelDir.absolutePath).use { model ->
        Recognizer(model, 16000f).use { rec ->
            rec.setWords(true)
            var i = 0
            while (i < pcm.samples.size) {
                val len = minOf(4000, pcm.samples.size - i)
                if (rec.acceptWaveForm(pcm.samples.copyOfRange(i, i + len), len)) grab(rec.result)
                i += len
            }
            grab(rec.finalResult)
        }
    }
    val cues = ArrayList<Cue>(); var group = ArrayList<Triple<Long, Long, String>>()
    fun flush() { if (group.isNotEmpty()) cues += Cue(group.first().first, group.last().second, group.joinToString(" ") { it.third }); group = ArrayList() }
    for (w in words) {
        if (group.isNotEmpty() && (group.size >= 5 || w.second - group.first().first > 2500)) flush()
        group += w
    }
    flush()
    return cues
}
